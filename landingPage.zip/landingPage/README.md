# Landing Page Project
project description:"this is my first project i think it can be good."

used languages:{javascript,html,css}

Project Features:this project can be used for any device and any browser

new added functions:the new functions that i used in this project is
{scrollIntoView=>"to make my animation smooth"}
{getBoundingClientRect=>"to show which section i'am standup on it"}

adjusted things in css file:
.page__header {
    background: #00ffff;

    i changed the color of the header
}
.navbar__menu .menu__link:hover {
    background: #FF1493;

    i changed the background color of the navbar sections
}

adjusted things in html file:
adding 2 new sections to our file
